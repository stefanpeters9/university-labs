#include <iostream>
using namespace std;

class node	// class declartion for each node of the linked list 
{
	public:
		char character;			// stores user input 
		int integer;			// stores ASCII code of the character 
		node *next;				// points to next node to link the list 
		node(char input, node* ptr)	// constructor to initialize variables
		{
			character = input;
			integer = (int)input;
			next = ptr;
		};
};

int main()
{
	cout<<"Type a character to find out its ASCII code.(zero to display results)"<<endl; // prompt the user to enter characters 

	node *head=NULL;		// head pointer 

	while(1)
	{
		char input;		
		cin>>input;
		if(input == '0') break;		// breaks loop if user enters '0'
		head = new node(input, head);
		//cout<<head->integer<<endl;  
	}
	cout<<endl<<"character"<<"\t"<<"ASCII code"<<endl; 
	
	node* pointer = head;	// copy the head pointer to transverse the linked list 
	while (pointer != NULL)	
	{
		cout<<pointer->character<<"\t\t"<<pointer->integer<<endl;
		pointer = pointer -> next;		// move pointer to transverse the list
	}

	return 0;
}
