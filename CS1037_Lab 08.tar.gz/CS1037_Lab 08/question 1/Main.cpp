#include <iostream>
#include <iomanip>
#include "Account.h"
using namespace std;

//	Test Driver
int main()
{
	account account1(111, 1000.00);									//	Create an object Account1 with accountNumber 111 and balance $1,000
	cout<<"Account Number: "<<account1.getAccountNumber()<<endl		//	Return the accountNumber of Account1 
		<<"Balance: "<<setprecision(6)<<account1.getBalance()<<endl;//	Return the balance of Account1
	account1.setBalance(2000.00);									//	Set the balance of Account1 to $2,000
	account1.credit(500.00);										//	Deposit $500 into Account1
	account1.debit(1500.00);										//	Withdraw $1,500 from Account1
	account1.print();												//	Print the details of Account1

	account account2(112 ,0.00);										//	Create an object Account2 with accountNumber 112 
	cout<<"Account Number: "<<account2.getAccountNumber()<<endl		//	Return the accountNumber of Account2
		<<"Balance: "<<setprecision(6)<<account2.getBalance()<<endl;//	Return the balance of Account2
	account2.setBalance(1000.00);									//	Set the balance of Account2 to $1,000
	account2.debit(1200.00);										//	Withdraw $1,200 from Account2
	account2.credit(800.00);										//	Deposit $800 from Account2
	account2.print();												//	Print the details of Account1

	return 0;
}