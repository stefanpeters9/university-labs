#include <iostream>
using namespace std;

class A {
 public:
  int x;
 public:
  A() { x = 0;}
  void increment() { x++; }
  void decrement() { x--; }
  void print() {cout << "x = " << x << endl;}
};

class B : private A {
 public:
  int y;
  B() { y = 0; }
  void increment() { x = x + 2; }
  void decrement() { x = x - 2; }
  void print() {cout << "y = " << y << endl;
				cout << "x = " << x << endl; }
};

/*class C : public B{
public:
		C() {x=100;}
};*/

int main() {
  A a;       // a is an object of class A
  A * ptr;   // ptr is a pointer to an object of class A
  B b;		// b is an object of class B
  B * ptr1;
  ptr1 = &b;
  ptr = &a;
 // b.x=100;				// the inherited x is the x that is changed.
  //ptr1 ->print();
  //b.print();				//.9
  //b.A::print();			//.10
  
 // C c;

  ptr -> print();
  ptr -> increment();
  ptr -> print();
  ptr -> decrement();
  ptr -> print();

  ptr1 -> print();
  ptr1 -> increment();
  ptr1 -> print();
  ptr1 -> decrement();
  ptr1 -> print();

 // ptr1->A::print();      6. 
}
/* initial output 
x = 1 
x = 0

1.	In the first case the constructor from A gets celled because there is no constructor in class B
	then the increment/ decrement functions get called from B becasue they are overridden 
	functions.

2.	Same as the first case.

7.	Was not able to run the code because variable x is no longer accesible to class B

11. b can not directly access functions in A when A is protected

12. it assumes that class is privately inheritated.

13. yes

14. yes

15. no
	
	*/