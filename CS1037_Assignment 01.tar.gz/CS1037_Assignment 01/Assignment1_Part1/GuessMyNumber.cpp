#include <iostream>
using namespace std;
//Defines a struct that asks as the nodes for the linked list
struct ListNode
{
	int asciiValue; //the ascii value of the char 
	char input; //the char
	ListNode *next; //a pointer to the next node in the list. If it is null, then it is the last node

	//constructor to initialize a new node
	ListNode(char input)
	{
		this->input = input; //sets the char to the char specified in the constructor call
		asciiValue = input; //conversion from char to int results in ascii value
		next = NULL; //sets the next node to null
	}
};

int main ()
{
	ListNode *head;  //create a listnode for the head	
    char input; //variable to read into	
	cout<<"Enter characters seperated by carriage return. 0 to stop"<<endl;
    cin>>input; //read in	
	if (input!='0') //if they didn't enter 0	
    {		
        head = new ListNode (input); //initialize the head to the first number entered in		
        ListNode *iterator = head; //define a new node * to iterate that starts at head		
        do
		{		
			cin>>input;
			if (input!='0') //don't make a new node if zero is entered 
			{
				iterator->next = new ListNode(input); //if not zero, create a new node and have the iterator point to it
                iterator = iterator->next;
            }	
        }
		while (input!='0'); //keep accepting numbers until 0 is entered 	
        iterator =head; //reset the iterator to the head	
        while (iterator!=NULL) //traverse the list until the end 
        {			
            cout<<"Char: "<<iterator->input<<" Ascii: "<<iterator->asciiValue<<endl; //output char and ascii value			
            iterator= iterator->next; //increment iterator		
        }	

		//clean up - delete all elements in the list
		iterator = head;  // Start at head of list
		while (iterator != NULL)
		{
			// garbage keeps track of node to be deleted
			ListNode *garbage = iterator;
			// Move on to the next node, if any
			iterator = iterator->next;
			// Delete the "garbage" node
			delete garbage;
		}

		//prevent dangling pointers
		head =NULL;
		iterator =NULL;
    }	
	return 0;
}
