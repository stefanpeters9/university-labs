#include "author.h"
#include <string>
#include <iostream>
using namespace std;

author::author()				// default constructor needed for book constructor
{
	name = "";					//empty string
	email = "";					//empty string
	gender = NULL;				//null character
}
author::author(string Name, string Email, char Gender)
{
	name = Name;								
	setEmail(Email);
	if (Gender == 'f' || Gender == 'm')			//	if not male or female
		gender = Gender;						//	set as 'u' for unknown
	else gender = 'u';
}
const string author::getName()
{
	return name;
}
const string author::getEmail()
{
	return email;
}
const char author::getGender()
{
	return gender;
}
void author::setEmail(string Email)
{
	if(Email.find('@')<100)		// email must contain '@'
	{
		if(Email.find('@') != 0 && Email.find('@') != Email.length()-1)		// '@' cannot be at he begining or end
			email = Email;
	}
	else
	{
		cout<<"\nInvalid Email!\n";
		Email.clear();				//set email to "" if it is invalid
	}
}
void author::print()
{
	cout<<"\n"<<getName()<<" "<<getGender()<<" at "<<getEmail()<<endl;
}