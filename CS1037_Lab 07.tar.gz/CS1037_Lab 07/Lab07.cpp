#include <list>
#include <iostream>
using namespace std;

int main()
{
	list<int> mylist;
	list<int>::iterator iter;

// a. using function push_front()
	mylist.push_front(5);
	mylist.push_front(7);
	mylist.push_front(10);
	mylist.push_front(25);
// b. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// c. using push_back()
	mylist.push_back(7);
	mylist.push_back(35);
	mylist.push_back(2);
	mylist.push_back(55);
	mylist.push_back(35);
	mylist.push_back(12);
// d. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// e. using function pop_front()
	mylist.pop_front();
	mylist.pop_front();
// f. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// g. using function pop_back()
	mylist.pop_back();
// h. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// i. using function reverse()
	mylist.reverse();
// j. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// k. using function insert()
	list<int>::iterator iter2;
	for(iter2=mylist.begin(); iter2!=mylist.end(); iter2++)
	if(*iter2 == 2) break;
	mylist.insert(iter2,99);
// l. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// m. using function remove()
	mylist.remove(55);
// n. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// o. using function sort()
	mylist.sort();
// p. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// q. using function unique()
	mylist.unique();
// r. using iterator to traverse the list
	for(iter=mylist.begin(); iter!=mylist.end(); iter++)
	cout<<*iter<<" ";
	cout<<endl;
// s. using function size()
	cout<<mylist.size()<<endl;



	return 0;
}
