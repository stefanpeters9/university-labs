#include <iostream>
using namespace std;

class class2	// class2 goes first so that it can be in the argument list for accessclass2 function
{
public:
	int y;	
	class2()	//	all class2 objects initiated with y=10
	{
		y=10;
	}
	void print()	// prints 10
	{
		cout<<y<<endl;
	}
};
class class1	
{
public:
	int x;
	class1()	// all class1 objects initiated with x=0, not that it matters
	{
		x = 0;
	}
	void accessclass2(class2 *ptr)	// class2 pointer will allow direct access to class2 functions 
	{
		ptr->print();
	}
};

int main()
{
	class1 instance;	// need class1 object to use accessclass2 function
	class2 instance2;	// need class2 object to use print()
	class2* pointer;	
	pointer = &instance2;
	instance.accessclass2(pointer);	// output: 10
	

	return 0;
}