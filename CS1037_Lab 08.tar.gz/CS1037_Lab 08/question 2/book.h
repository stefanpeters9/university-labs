#ifndef BOOK_H
#define BOOK_H
#include <string>
#include "author.h"
using namespace std;

class book
{
private:
	string name;							//	1. Name of the book
	author Author;							//	2. this is an object of class author
	double price;							//	3. price of the book must be positive
	int qtyInStock;							//	4. amount of inventory must be positive or zero
public:	
	book(string, author, double, int);		//	5. contrustor with 4 arguments
	const string getName();					//	6. returns the name of the book
	const author getAuthor();				//	7. returns the name of the author
	const double getPrice();				//	8. returns the price of the book
	void setPrice(double);					//	9. sets and validates the price
	const int getQtyInStock();				//	10. returns the quantity in stock
	void setQtyInStock(int);				//	11. sets and validates quantity (>=0)  else set to 0
	void print();							//	12. function that prints "name(gender) at email"
	const string getAuthorName();			//	13. returns the name of the author
};
#endif