#include"header.h"
#include<iostream>
using namespace std;

int main()
{
	truck pickup;	//a. Create an object of type Truck of weight 30,000
	pickup.weight = 30000;
	car sedan;				//b. Create an object of type car
	sedan.tire[0].inflate(10);	//c. Inflate the first tire (the first element of the array) by 10 psi
	sedan.right.close();		//d. Close the right door
	sedan.left.window.rollup();	//e. Roll up the window of the left door
	sedan.engine.start();		//f. Start the engine
	return 0;
}
