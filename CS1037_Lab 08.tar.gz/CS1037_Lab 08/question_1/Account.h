#ifndef ACCOUNT_H
#define ACCOUNT_H

class account
{
	private:
		int accountNumber;
		double balance;
	public:
		account(int, double);
		const int getAccountNumber();
		const double getBalance();
		void setBalance(double);
		void credit(double);
		void debit(double);
		void print();
};
#endif