#include "book.h"
#include "author.h"
#include <string>
#include <iostream>
using namespace std;


book::book(string name, author Author, double price, int qtyInStock)	// names of the arguments must be the same as the variables
{
	book::name=name;
	book::Author=Author;
	book::price=price;
	book::qtyInStock=qtyInStock;
}
const string book::getName()		//	6. returns the name of the book
{
	return name;
}
const author book::getAuthor()		//	7. returns the name of the author
{
	return Author;
}
const double book::getPrice()			//	8. returns the price of the book
{
	return price;
}
const int book::getQtyInStock()			//	10. returns the quantity in stock
{
	return qtyInStock;
}
const string book::getAuthorName()		//	13. returns the name of the author
{
	return Author.getName();
}
void book::setPrice(double price)			//	9. sets and validates the price
{
	if(price>0)
		book::price=price;
}
void book::setQtyInStock(int qtyInStock)		//	11. sets and validates quantity (>=0)  else set to 0
{
	if(qtyInStock>=0)
		book::qtyInStock = qtyInStock;
	else 
	{
		cout<<"\nquantity cannot be negative\n";
		book::qtyInStock = 0;
	}
}
void book::print()								//	12. function that prints "name(gender) at email"
{
	cout<<"\n"<<getName()<<" by ";
	Author.print();

}