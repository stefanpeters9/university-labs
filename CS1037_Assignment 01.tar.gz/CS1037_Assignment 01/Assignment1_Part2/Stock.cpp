#include "Stock.h"

stock::stock()
{
	itemNumber = 0;
	quantity = 0; 
	cost = 0;
}
stock::stock(int itemNbr, int qunty, double cst)
{
	setItemNumber(itemNbr);
	setQuantity(qunty);
	setCost(cst);
}
bool stock::setItemNumber(int number)
{
	bool valid = true;

	if(number>=0)
		itemNumber = number;
	else valid = false;

	return valid;
}
bool stock::setQuantity(int qty)
{
	bool valid = true;

	if(qty>=0)
		quantity = qty;
	else valid = false;

	return valid;
}
bool stock::setCost(double cst)
{
	bool valid = true;

	if(cst>=0)
		cost = cst;
	else valid = false;

	return valid;
}
int stock::getItemNumber()
{
	return itemNumber;
}
int stock::getQuantity()
{
	return quantity;
}
double stock::getCost()
{
	return cost;
}
double stock::getTotalCost()
{
	return quantity*cost;
}
