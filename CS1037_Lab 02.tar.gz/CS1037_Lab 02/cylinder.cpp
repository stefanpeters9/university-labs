#include "cylinder.h"
#include <iostream>
using namespace std;

double cylinder::getSurfaceArea() {return ((2*3.14159*radius*height)+(2*3.14159*(radius*radius)));};
double cylinder::getVolume() {return (3.14159*(radius*radius)*height);};
void cylinder::setRaduis(double r) {radius = r;};
void cylinder::setHeight(double h) {height = h;};

int main()
{

	cylinder cylinder1, cylinder2(3,12);
	cylinder1.setRaduis(5);
	//cylinder1.radius = 1;					//Error: Cannot access private member
	cylinder1.setHeight(10);				// When accessors are deleted the private member attributes could not be set
	//cylinder2.setRaduis(3);					
	//cylinder2.setHeight(12);

	cout<<"\n\tCylinder1\n\nVolume: "<<cylinder1.getVolume()
		<<"\nSurface Area: "<<cylinder1.getSurfaceArea()<<endl<<endl;

	cout<<"\n\tCylinder2\n\nVolume: "<<cylinder2.getVolume()
		<<"\nSurface Area: "<<cylinder2.getSurfaceArea()<<endl<<endl;

	
	return 0;
}