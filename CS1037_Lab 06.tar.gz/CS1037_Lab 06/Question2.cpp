#include <iostream>
#include <vector>
using namespace std;

	struct linkListNode	// struct for each node
	{
		linkListNode *next;
		int data;
		linkListNode(int d, linkListNode* p =NULL)
		{
			data = d;
			next = p;// every node has a pointer that points to the previous node
		}
	};

bool prime(int x)		// 3.
{
	int counter=0;
	for(int i=1; i<=x; i++)
	{
		if(!(x%i)) counter++;
	};
	if(counter==2) return true;
	else return false;
};

int main()
{
	int arr[100];
	for(int i=0; i<100; i++) // 1. Declare an array called arr of size 100 that stores all the integers from 1 to 100 inclusive. 
	{
		arr[i] = i+1;
	}
	
	vector<int> vint;	// 2. Declare a vector called vint of size zero that stores integers

	for(int i=0; i<100; i++)
	{
		if(prime(arr[i]) == true)
		{
			vint.push_back(arr[i]); // 3. 
		}
	};
	
	vint.insert(vint.begin(),0); // 4.



	linkListNode *head = NULL; // how to start a linked list 

	for(int i=99; i>=0 ; i--)
	{
		if(prime(arr[i]) == true)
		{
			head = new linkListNode(arr[i],head); // head points to a node that points the old value of head, initially NULL
		}
	};

	head = new linkListNode(0,head);// just another node with a value of 0

	// to insert a node in the middle
	linkListNode *previousNode = head; 
	linkListNode *nodePtr = head->next;
	while(nodePtr != NULL && nodePtr->data < 1)
	{
		previousNode = nodePtr;
		nodePtr = nodePtr->next;
	}

	previousNode->next = new linkListNode(1, nodePtr);

	linkListNode *nodePtr3 = head;

	//printing a linked list
	while (nodePtr3 != NULL)
	{
		cout<<nodePtr3->data<<" ";
		nodePtr3 = nodePtr3 -> next;
	}

	cout<<endl<<endl;


	linkListNode *previousNode2 = head;
	linkListNode *nodePtr2 = head->next;
	while(nodePtr2 != NULL && nodePtr2->data != 19)
	{
		previousNode2 = nodePtr2;
		nodePtr2 = nodePtr2->next;
	}

	// finding a certain node to delete, notice the
	//first part of locating the node is the same as before
	previousNode2->next = nodePtr2->next;
    delete nodePtr2;

	while (head != NULL)
	{
		cout<<head->data<<" ";
		head = head -> next;
	}

	cout<<endl<<endl;

	return 0;
}
