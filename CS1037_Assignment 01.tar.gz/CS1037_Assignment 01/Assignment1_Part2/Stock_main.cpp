#include <iostream>
#include "Stock.h"
using namespace std;

int main()
{
	stock stockItem;
	int itemNum, qunty;
	double cst;
	
	cout<<"Set the item number: ";
	cin>>itemNum;
	if(!stockItem.setItemNumber(itemNum))
		cout<<"\nInvalid item number.";
	cout<<"\nSet the quantity: ";
	cin>>qunty;
	if(!stockItem.setQuantity(qunty))
		cout<<"\nInvalid quantity amount.";
	cout<<"\nSet the cost: ";
	cin>>cst;
	if(!stockItem.setCost(cst))
		cout<<"\nInvalid cost.";

	cout<<"\nHere is the stock items data: "
		<<"\n\n\tItem number: \t\t"<<stockItem.getItemNumber();
	cout<<"\n\tQuantity: \t\t"<<stockItem.getQuantity();
	cout<<"\n\tCost: \t\t\t"<<stockItem.getCost();
	cout<<"\n\tTotal cost: \t\t"<<stockItem.getTotalCost()<<endl<<endl;

	return 0;
}
