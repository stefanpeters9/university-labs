#ifndef AUTHOR_H
#define AUTHOR_H
#include <string>
using namespace std;

class author
{
private:
	string name;							//	1. Name of the author
	string email;							//	2. Email of the author. It must contain the character �@�
	char gender;							//	3. The gender of the author. It should be either �m� or �f� or �u� for unknown
public:
	author();								//	default constructor
	author(string, string, char);			//	4. constructor that takes 3 arguments
	const string getName();					//	5a. name accessor
	const string getEmail();				//	5b. email accessor
	void setEmail(string);					//	6. setting and validation of the email
	const char getGender();					//	5c. gender accessor
	void print();							//	7. function that prints "name(gender) at email"
};
#endif