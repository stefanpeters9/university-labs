#include <iostream>				//	need to have this for 
using namespace std;			//	the cout statement to work
#ifndef CYLINDER_H
#define CYLINDER_H

class cylinder
{
private:
	double	radius,
		    height;
public:
	//double	radius;						//allows direct access to radius from cylinder.cpp
	/*double	getSurfaceArea() {return ((2*3.14159*radius*height)+(2*3.14159*(radius*radius)));};
	double	getVolume() {return (3.14159*(radius*radius)*height);};
	void	setRaduis(double r) {radius = r;};
	void	setHeight(double h) {height = h;};*/

	cylinder()							// cannot have a return type because it has the same name as the class
	{
		radius = 1;
		height = 1;
		cout<<"\nI'm the default constructor!\n";
	}
	cylinder(double h, double r)
	{
		radius = r;
		height = h;
	}
	double	getSurfaceArea();
	double	getVolume();
	void	setRaduis(double);
	void	setHeight(double);
	~cylinder() {cout<<"\n\nThe destructor\n\n";};						//only one destructor allowed per class
};
#endif