#include"header.h"
#include<iostream>
using namespace std;

vehicle::vehicle()	// note2: intitial values must be done through contructors
{
	weight = 0;
}
const void engine::start()	// start() of type void. It should print �engine started�
{
	cout<<"engine started."<<endl;
}
const void engine::stop()	//stop() of type void. It should print �engine stopped
{
	cout<<"engine stopped."<<endl;
}
tire::tire()	// note2: intitial values must be done through contructors
{
	pressure = 30;
}
int tire::inflate(int psi)// inflate() of type integer that takes one integer argument called psi .This function will add the 
{							//value of psi to pressure and then it returns the new pressure of the tire
	pressure += psi;
	return pressure;
}
const void window::rollup()	// rollup() of type void. It should print �window is up�
{
	cout<<"window is up."<<endl;
}
const void window::rolldown()		// rolldown() of type void. It should print �window is down�
{
	cout<<"window is down."<<endl;
}
const void door::open()	// open() of type void. It should print �door is open
{
	cout<<"door is open."<<endl;
}
const void door::close()		// close() of type void. It should print �door is close
{
	cout<<"door is closed."<<endl;
}
