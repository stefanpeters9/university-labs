#include<iostream>
#include<string>
using namespace std;

struct movieData
	{
		movieData()
		{
			title = "Movie Title";
			director = "Mr. Director";
			year = 2015;
			time = 180;
		}
		string title;
		string director;
		int year;
		int time;
	};
void displayMovie(movieData movie)
{
	cout<<"\n\nMovie Title: \t\t"<<movie.title
		<<"\nDirector: \t\t"<<movie.director
		<<"\nYear Released: \t\t"<<movie.year
		<<"\nMovie Duration: \t"<<movie.time<<" min\n\n";
}

int main()
{
	movieData movie1, movie2;
	displayMovie(movie1);
	displayMovie(movie2);
	return 0;
}
