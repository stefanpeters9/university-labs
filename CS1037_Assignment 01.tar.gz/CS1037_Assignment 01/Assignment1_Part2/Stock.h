#ifndef STOCK_H
#define STOCK_H

class stock
{
private:
	int itemNumber;
	int quantity; 
	double cost;
public:
	stock();
	stock(int, int, double);
	bool setItemNumber(int);
	bool setQuantity(int);
	bool setCost(double);
	int getItemNumber();
	int getQuantity();
	double getCost();
	double getTotalCost();
};
#endif
