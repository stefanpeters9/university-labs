#include "cs1037lib-window.h"
#include "cs1037lib-image.h"
#include <iostream>
using namespace std;
void main()
{
SetWindowTitle("Lab 1");
SetWindowVisible(true); // Show main window
int map = LoadImage("london.png"); // Load image from file
int stamp = LoadImage("stamp.png");
DrawImage(map,0,0); // Draw image at xy position (0,0) 
int x,y,button;
while (!WasWindowClosed())
{
	if (GetMouseInput(&x,&y,&button)) {
		if (button > 0)
			DrawImage(stamp,x,y);
		else
			cout << "mouse moved to " << x << "," << y << endl; 
	}
}
DeleteImage(map); // Free memory used by image
}