#include <iostream>
#include <iomanip>
#include "Account.h"
using namespace std;

account::account(int accntNumbr, double blance)
{
	accountNumber = accntNumbr;
	setBalance(blance);
}
const int account::getAccountNumber()
{
	return accountNumber;
}
const double account::getBalance()
{
	return balance;
}
void account::setBalance(double balnce)
{
	balance = balnce;
}
void account::credit(double credit)
{
	balance += credit;
}
void account::debit(double debit)
{
	if(debit<balance)
		balance -= debit;
	else cout<<"\namount withdrawn exceeds the current balance\n";
}
void account::print()
{
	cout<<"\nAccount Number: "<<getAccountNumber()<<"\tBalance: $"<<setprecision(6)<<getBalance()<<endl<<endl;
}