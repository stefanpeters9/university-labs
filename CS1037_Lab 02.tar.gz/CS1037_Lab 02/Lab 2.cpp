#include <iostream>
#include <chrono>
#include <ctime>
using namespace std;
const int length = 200000;
long *myArray = new long [length];
int key = 100;
void sortArray(const int, long [])
{

	srand((unsigned int)time(NULL));

	for (int i=0;i<length;i++)
	{
		myArray[i]=rand()%75001;
	}

	for(int i=0;i<length-1;i++)
	{
		int currentMin = myArray[i];
		int currentMinindex=i;
		for(int j=i+1;j<length;j++)
		{
			if(currentMin>myArray[j])
			{
				currentMin=myArray[j];
				currentMinindex=j;
			}
			if(currentMinindex!=i)
			{
				myArray[currentMinindex]= myArray[i];
				myArray[i]=currentMin;
			}		
		}
	}
	for(int i=0;i<length;i++)
	{
		cout<<" "<<myArray[i];
	}
}
int linearSearch(const int, long [], int)
{

	for(int i=0;i<length;i++)
	{
		if(key==myArray[i])
			return i;
	}
	return -1;
}
int binarySearch(const int, long[], int)
{
	int low = 0;
	int high = length-1;
	while (high >= low)
	{
		int mid = (low + high) / 2;
		if (key < myArray[mid])
			high = mid-1;
		else if (key == myArray[mid])
			return mid;
		else low = mid + 1;
	}
	return low-1;
}

int main()
{
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();

	sortArray(length, myArray);
	
	/*if(linearSearch(length, myArray, key)>0)
		cout<<endl<<"Found";
	else cout<<endl<<"Not Found";*/

	cout<<endl<<binarySearch(length, myArray, key);
		
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	auto duration=
		std::chrono::duration_cast<std::chrono::microseconds>(t2-t1).count();
	cout<<endl<<"Time:\t"<<duration<<endl<<endl;;
}

/*
Results:
						For an array of length 100,000

				5.	16188926 microseconds to sort the array

				7.	16182925  microseconds linear search for 10000

				9.	16194926 microseconds linear search for 80000

				11.	16181925 microseconds binary search for 10000

				13.	16182925 microseconds binary search for 80000

							For an array of length 200,000

				5.	64577693 microseconds to sort the array

				7.	66764818  microseconds linear search for 10000

				9.	65066721 microseconds linear search for 80000

				11.	64611695 microseconds binary search for 10000

				13.	64578693 microseconds binary search for 80000



*/