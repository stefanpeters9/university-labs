#include <iostream>
#include <string>
#include "book.h"
using namespace std;

int main()
{
	author author1("John","John87@uwo.ca",'i');	//a. Create an Author object with valid email and invalid gender
	author1.print();							//b. Print Author�s details
	author1.setEmail("@john.com");				//c. Validate the email(call the setEmail() and enter an invalid email; e.g. �@john.com�
	cout<<author1.getEmail()<<endl				
		<<author1.getName()<<endl				//d. Call the three accessors in the Author�s class
		<<author1.getGender()<<endl;			

	book book1("Code", author1, 9.99, 20);		//e. Create a Book object
	book1.setQtyInStock(-87);					//f. Validate the qtyInStock(call the function and pass a negative number)
	cout<<book1.getName()<<endl
		<<book1.getPrice()<<endl
		<<book1.getAuthorName()<<endl			//g. Call all other functions 
		<<book1.getQtyInStock()<<endl;
	book1.getAuthor();
	book1.print();
		

	return 0;
}
