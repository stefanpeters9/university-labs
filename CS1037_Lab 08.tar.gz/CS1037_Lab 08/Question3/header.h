#ifndef HEADER_H
#define HEADER_H		// note 3: you should include guards
using namespace std;

class vehicle	// a.
{
public:
	float weight;	//weight of type float, initial value is zero
	virtual const void print(){};// print() abstract function of type void
	vehicle();	// note2: intitial values must be done through contructors
};		
class truck :public vehicle	// b. clss truck inherits from vehicle 
{
public:

};
class engine	// c. 
{
public:
	const void start();// start() of type void. It should print �engine started�
	const void stop();//stop() of type void. It should print �engine stopped
};
class tire	// d. 
{
public:
	int pressure;	//pressure of type integer, initial value is 30
	int inflate(int);// inflate() of type integer that takes one integer argument called psi .This function will add the value of psi to pressure and then it returns the new pressure of the tire
	tire();
};
class window		// e.
{
public:
	const void rollup();// rollup() of type void. It should print �window is up�
	const void rolldown(); // rolldown() of type void. It should print �window is down�
};
class door  // f.
{
public:
	window window; // window of type Window
	const void open();	// open() of type void. It should print �door is open
	const void close(); // close() of type void. It should print �door is close
};
class car :public vehicle	// g. car inherits from vehicle 
{
public:
	engine engine;		// engine of type Engine
	tire tire[4];	// tire , an array of 4 tires, of type Tire
	door left;		//	left of type Door
	door right;		// right of type Door
};

#endif 
